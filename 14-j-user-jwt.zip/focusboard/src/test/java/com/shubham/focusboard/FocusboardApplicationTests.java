package com.shubham.focusboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FocusboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
