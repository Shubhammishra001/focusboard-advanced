package com.shubham.focusboard.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.shubham.focusboard.dao.TaskDao;
import com.shubham.focusboard.repository.UserRepository;
import com.shubham.focusboard.service.TaskService;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class TaskServiceImpl implements TaskService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;


	
	
	

	
	
	
}
