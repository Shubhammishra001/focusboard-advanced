package com.shubham.focusboard.service;

public interface TaskService {

}
