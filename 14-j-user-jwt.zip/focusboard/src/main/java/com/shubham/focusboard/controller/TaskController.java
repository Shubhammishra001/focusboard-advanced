package com.shubham.focusboard.controller;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shubham.focusboard.enties.Task;
import com.shubham.focusboard.exception.ReqProcessingException;
import com.shubham.focusboard.service.TaskService;

@RestController
public class TaskController {
	 private static final Logger logger = LoggerFactory.getLogger(TaskController.class);

    	//@Autowired
	   //private TaskService taskService;
 
	   @PostMapping
	    public Task createTask(@RequestBody Task task)throws ReqProcessingException {
		   try {
			     if(Objects.nonNull(task)) {
			    	 
			     }
		        logger.info("API: createTask");
		       // return taskService.createTask(task);
		        return null;
		   }
		   catch(Exception e) {
			   
		   }
		   return null;
	    }
	
	
}
