package com.shubham.focusboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FocusboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(FocusboardApplication.class, args);
		System.err.println(" ready to start ");
	}

}
