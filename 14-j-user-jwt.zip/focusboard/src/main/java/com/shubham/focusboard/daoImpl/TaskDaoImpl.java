package com.shubham.focusboard.daoImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.shubham.focusboard.dao.TaskDao;
import com.shubham.focusboard.enties.Task;
import com.shubham.focusboard.repository.TaskRepository;
@Repository
public class TaskDaoImpl implements TaskDao{
	//@Autowired
//	private TaskRepository taskRepository;
	@Override
	public Task Save(Task task) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Task> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Task> findById(Long id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public List<Task> findbyUserId(Long userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		
	}
}
